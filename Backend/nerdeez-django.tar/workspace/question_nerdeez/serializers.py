from question_nerdeez.models import Question
from rest_framework import serializers
from django.contrib.auth.models import User
'''
#tried to create a serializer of the User Object 
#so that i'd be able to see the name in the JSON.
#Couldn't figur it out in time...
class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ('pk', 'name')
   '''     
class QuestionSerializer(serializers.ModelSerializer):
    #author=UserSerializer(many=True)
    class Meta:
        model = Question
        fields = ('pk', 'title', 'description', 'author')