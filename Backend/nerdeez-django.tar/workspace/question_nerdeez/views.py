from django.shortcuts import render

#from rest_framework.renderers import JSONRenderer
from rest_framework.response import Response
from rest_framework.decorators import api_view

from question_nerdeez.models import Question
from question_nerdeez.serializers import QuestionSerializer

@api_view(['GET'])
def get_q(request, **kwargs):
    question = Question.objects.all()
    serializers = QuestionSerializer(question, many=True)
    return Response(serializers.data)
    
@api_view(['GET'])
def get_one_q(request, **kwargs):
    pk=request.data['pk']
    question = Question.objects.get(pk=pk)
    serializer = QuestionSerializer(question)
    return Response(serializer.data)
    
@api_view(['POST'])
def post_q(request, **kwargs):
    
    title=request.data['title']
    description=request.data['description']
    author=request.data['author']
    
    question = Question.objects.create(title=title,
                            description=description,
                            author=author)
    serializer = QuestionSerializer(question)
    question.objects.add(question)
    question.save()
    return Response(serializer.data)

@api_view(['PUT'])
def put_q(request, **kwargs):
    pk=request.data['pk']
    question = Question.objects.get(pk=pk)
    serializer = QuestionSerializer(question)
    title=request.data['title']
    description=request.data['description']
    author=request.data['author']
    
    question = Question.objects.create(title=title,
                            description=description,
                            author=author)
    serializer = QuestionSerializer(question)
    
    new_title, new_description, new_author=""
    title=new_title
    description=new_description
    author=new_author
                            
    question = Question.objects.create(title=title,
                            description=description,
                            author=author)
    serializer = QuestionSerializer(question)
    question.objects.add(question)
    question.save()
    return Response(serializer.data)

@api_view(['DELETE'])
def delete_q(request, **kwargs):
    pk=request.data['pk']
    question = Question.objects.get(pk=pk)
    
    serializer = QuestionSerializer(question)
    Response(serializer.data)
    question.delete()
    
    return "The Question was Deleted.."

# i didn't get a chance to run tests on all the CRUD function,
# and i wrote it out really quickly and under very little sleap..