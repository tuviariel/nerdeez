from django.db import models

from django.contrib.auth.models import User


class Question(models.Model):
    title=models.CharField(max_length=50)
    description=models.TextField(max_length=300)
    # it was recomended that i create a user that is not the Django biult in user
    # so that the user attributes would be easyer to alter. for this project, 
    # after trying and getting stuck i decided to leave it the simple way... 
    author=models.ForeignKey(User)
    #though i still didn't figur out how to see the name in the Json and not the PK...
    #see comments in the serializers.py
    
    def __unicode__(self):
        return u'{t}{d}'.format(t=self.title, d=self.description)
